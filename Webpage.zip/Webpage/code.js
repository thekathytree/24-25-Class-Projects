function tada(event){
    event.preventDefault();
    alert("Your submission was succesful. \nA confirmation email with your order will be sent shortly!")
}
