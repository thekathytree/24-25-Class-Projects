module com.svgs {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.desktop;
    requires javafx.media;
    requires java.sql;

    opens com.svgs to javafx.fxml;
    exports com.svgs;
}
