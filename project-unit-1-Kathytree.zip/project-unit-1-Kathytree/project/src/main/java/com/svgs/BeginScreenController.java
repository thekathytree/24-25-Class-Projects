package com.svgs;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class BeginScreenController {

    @FXML
    private Button beginButt;

    @FXML
    private AnchorPane beginScreen;

    @FXML
    private Label titleLbl;
    @FXML
    private Label tipLbl;
    
    public static String user;

    @FXML
    void initialize()
    {
        PokedexQuestController.pokeFont = Font.loadFont(getClass().getResourceAsStream("pokemonfirered.ttf"), 45);
        titleLbl.setFont(Font.font("Pokemon Fire Red", 55));
        beginButt.setFont(Font.font("Pokemon Fire Red", 30));
        tipLbl.setFont(Font.font("Pokemon Fire Red", 20));

    }
    @FXML
    public void beginJourney(ActionEvent event) {
      try {
        App.setRoot("pokedexQuest");
    } catch (IOException e) {
        System.out.println(e);
    } 
    }

}