package com.svgs;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class WinScreenController {

    @FXML
    private Button againButt;

    @FXML
    private Button closeButt;

    @FXML
    void close(ActionEvent event) {
        Stage stage;
        stage = (Stage) closeButt.getScene().getWindow();
        stage.close();
    }

    @FXML
    void playAgain(ActionEvent event) {
        FXMLLoader floot = new FXMLLoader(getClass().getResource("pokedexQuest.fxml"));
       Scene scene;
    try {
        scene = new Scene(floot.load());
        Stage stage = new Stage();
       stage.setScene(scene);
       stage.show();
       stage = (Stage) againButt.getScene().getWindow();
       stage.close();
    } catch (IOException e) {}
    }

}
