package com.svgs;

import javafx.scene.image.Image;
import javafx.scene.media.*;
public class Pokemon {

public String name;
private Image sil;
private Image reveal;
private String hint;
private Media cry;
    
    @SuppressWarnings("exports")
    public Pokemon(String n, Image s, Image r, String h, Media c){
        name = n;
        sil = s;
        reveal = r;
        hint = h;
        cry = c;
    }

    Image getSilhouette()
    {
        Image s = sil;
        return s;
    }

    Media getSound()
    {
       return cry;
    }

    Image getRevealed()
    {
        Image r = reveal;
        return r; 
    }

    String getHint()
    {
        String h = hint;
        return h;
    }

    String getName(){
        String n = name;
        return n;
    }

}
