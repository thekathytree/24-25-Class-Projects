package com.svgs;

import java.util.ArrayList;

public class Player {

public String username;
public int highscore;
private ArrayList<String> guessed = new ArrayList<>();
    
@SuppressWarnings("unchecked")
public Player(String u, int hs, ArrayList<String> a)
{
    username = u;
    highscore = hs;
    for(String e : a)
    {
        guessed.add(e);
    }
    
}
    public String getName()
    {
        return username;
    }

    public ArrayList<String> getList()
    {
        return guessed;
    }

    public int getScore()
    {
        return highscore;
    }
}
