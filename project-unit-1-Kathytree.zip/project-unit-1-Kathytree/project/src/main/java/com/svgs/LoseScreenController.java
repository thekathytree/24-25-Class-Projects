package com.svgs;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class LoseScreenController {

    @FXML
    private Label loseScore;

    @FXML
    private Button closeButt;

    @FXML
    private Button againButt;

    @FXML
    void initialize()
    {
        try{
        loseScore.setText(PokedexQuestController.scoreTracker + "/35");
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }
    @FXML
    void close(ActionEvent event) throws IOException {
        Stage stage;
        stage = (Stage) closeButt.getScene().getWindow();
        stage.close();
    }

    @FXML
    void playAgain(ActionEvent event) {
      FXMLLoader floot = new FXMLLoader(getClass().getResource("pokedexQuest.fxml"));
       Scene scene;
    try {
        scene = new Scene(floot.load());
        Stage stage = new Stage();
       stage.setScene(scene);
       stage.show();
       stage = (Stage) againButt.getScene().getWindow();
       stage.close();
    } catch (IOException e) {
    }
    
       
    }

}