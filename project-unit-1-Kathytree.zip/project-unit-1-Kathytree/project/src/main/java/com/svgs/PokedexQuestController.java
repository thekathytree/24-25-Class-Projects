package com.svgs;

import java.util.*;
import java.io.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.media.*;

public class PokedexQuestController {
    @FXML
    private ToggleGroup multi;
    
    @FXML
    private RadioButton gssA;

    @FXML
    private RadioButton gssB;

    @FXML
    private RadioButton gssC;

    @FXML
    private RadioButton gssD;

    @FXML
    private Label gssCountLbl;
    
    @FXML
    private Button nxtButt;

    @FXML
    private Button hintButt;

    @FXML
    private TextField gssBox;

    @FXML
    private Button gssButt;

    @FXML
    private ImageView pokeDexB;
    
    @FXML
    private Label hintLbl;

    @FXML
    private Label scoreLbl;

    @FXML
    private ImageView pokeSil;

    @FXML
    private Pane pokedexScrn;

    @FXML 
    public static Font pokeFont;

    @FXML
    private Button playAgainButt; 

    private File pokeList;

    private ArrayList<Pokemon> shuffleList = new ArrayList<>();

    public static int scoreTracker = 0;

    private static int guesses = 0;

    private Pokemon a;

    @FXML
    private Button selectItBtt;

    @FXML
    private Button typeItbtt;

    @FXML
    private Button cryButt;

    private ArrayList<String> names = new ArrayList<>();
    
    private String corrName;
    
    private MediaPlayer medP;

    private ArrayList<Pokemon> init = new ArrayList<>();

    Image toImage(String s)
    {
        Image newImage = new Image(getClass().getResource("Pokemon Silhouettes/" + s + ".png").toString());
        return newImage;
    }

    Media toSound(String s)
    {
        Media so = new Media(getClass().getResource("Pokemon Cry/" + s + ".wav").toString());
        return so;
    }

    @FXML
    void initialize() throws IOException
    { 
        guesses = 0;
        scoreTracker = 0;
        pokeFont = Font.loadFont(getClass().getResourceAsStream("pokemonfirered.ttf"), 45);
        gssA.setToggleGroup(multi);
        gssB.setToggleGroup(multi);
        gssC.setToggleGroup(multi);
        gssD.setToggleGroup(multi);
        gssButt.setFont(Font.font("Pokemon Fire Red", 17));
        nxtButt.setFont(Font.font("Pokemon Fire Red", 17));
        nxtButt.setVisible(false);
        hintButt.setFont(Font.font("Pokemon Fire Red", 15));
        gssBox.setFont(Font.font("Pokemon Fire Red", 17));
        hintLbl.setFont(Font.font("Pokemon Fire Red", 20));
        gssCountLbl.setFont(Font.font("Pokemon Fire Red", 20));
        hintLbl.setVisible(false);
        scoreLbl.setFont(Font.font("Pokemon Fire Red", 22));
        scoreLbl.setText(scoreTracker + "/35");
        pokeList = new File("PokeList.txt");
        cryButt.setFont(Font.font("Pokemon Fire Red", 17));
        gssA.setFont(Font.font("Pokemon Fire Red", 18));
        gssB.setFont(Font.font("Pokemon Fire Red", 18));
        gssC.setFont(Font.font("Pokemon Fire Red", 18));
        gssD.setFont(Font.font("Pokemon Fire Red", 18));
        gssA.setVisible(false);
        gssB.setVisible(false);
        gssC.setVisible(false);
        gssD.setVisible(false);
        gssBox.setVisible(false);
        selectItBtt.setFont(Font.font("Pokemon Fire Red", 15));
        typeItbtt.setFont(Font.font("Pokemon Fire Red", 15));
        reloadNames();
        try {
            BufferedReader read = new BufferedReader(new FileReader(pokeList));
            String line = read.readLine();
      while (line != null) {
        String[] parts = line.split(":");
        Image sil = toImage(parts[1]);
        Image rev = toImage(parts[2]);
        Media sound = toSound(parts[4]);
        Pokemon pm = new Pokemon(parts[0].toLowerCase(), sil, rev, parts[3], sound);
        shuffleList.add(pm);
        for(Pokemon p : shuffleList)
        {
            names.add(p.getName());
        }
        line = read.readLine();
      } 
      read.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        pokeList = new File("User_Highscore.txt");
        /*try {
            BufferedReader read = new BufferedReader(new FileReader(pokeList));
            String line = read.readLine();
      while (line != null) {
        String[] parts = line.split(":");
        String[] pokeInfo = parts[2].split(";");
        ArrayList<String> pm = new ArrayList<>();

         for(int i = 2; i < pokeInfo.length; i++)
        {
        pm.add(pokeInfo[i]);
        }
        int scr = Integer.parseInt(parts[1]);
        Player p = new Player(parts[0], scr, pm);
        players.add(p);
        line = read.readLine();
        } 
        read.close();
        pokeList.delete();
        } catch (Exception e) {
            // TODO: handle exception
        }*/
        init.addAll(shuffleList);
        playGame();
        //loadPlayerGss();
    }
    /*@FXML
    void save(ActionEvent event) {
        pokeList = new File("User_Highscore");
        try {
            BufferedWriter write = new BufferedWriter(new FileWriter(pokeList));
            for (Player n : players)
            {
                write.write(n.getName() + ":");
                write.write(scoreTracker + ";");
                for(Pokemon pm : pokemons)
                {
                    write.write(pm.getName() + ";");
                }
                write.write("\n");
            }
            write.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }*/

    /*void loadPlayerGss()
    {
        for(Player am : players)
        {
            if(am.getName().equals(BeginScreenController.user))
            {
                pl = am;
            }
        }
        for(String ak : pl.getList())
        {
            for(Pokemon mon : shuffleList)
            {
            if(mon.getName().equals(ak))
            {
                shuffleList.remove(mon);
            }
        }
        }
        scoreTracker = getScore();
        scoreLbl.setText(scoreTracker + "/35");
    }*/

    @FXML
    void playCry(ActionEvent event) {
        medP = new MediaPlayer(a.getSound());
        medP.play();
    }
   
    int random(ArrayList l)//randomly selects a pokemon
   {
    int a = l.size();
    int random = (int) (Math.random() * a);
    return random;
   }
    
   @FXML
    public void playGame() throws IOException
    {
        if (scoreTracker == 35)
        {
            youWon();
        }
        int r = random(shuffleList);
        a = shuffleList.get(r);
        corrName = a.getName();
        pokeSil.setImage(a.getSilhouette());
    }
    @FXML
    void guessAMon(ActionEvent event) throws IOException{
        
       if(gssBox.isVisible())
       {
        typeGuess();
       }
       else
       {
        selectGuess();
       }
    }

    @FXML
    void typeGuess() throws IOException
    {
        String guessStr = gssBox.getText();
        if(!guessStr.toLowerCase().equals(a.getName())){
            gssBox.setText("Wrong. Guess again!");
            guesses++;
            updateGuessCount();
            gssBox.clear();
        }
        else if (!shuffleList.isEmpty())
        {
            gssBox.setText("Correct! Good job.");
            guesses=0;
            updateScore();
            updateGuessCount();
            pokeSil.setImage(a.getRevealed());
            gssButt.setVisible(false);
            nxtButt.setVisible(true);
        }
        if(guesses == 3){
            youLost();
        }
    }

    @FXML
    void selectGuess() throws IOException
    {
        RadioButton selectedAnswer = (RadioButton) multi.getSelectedToggle();
        if(selectedAnswer == null) {
            return;
        }
        if(!selectedAnswer.getText().equals(a.getName()))
        { 
            guesses++;
            updateGuessCount();
            
        }
        else if (!shuffleList.isEmpty())
        {
            guesses=0;
            updateScore();
            updateGuessCount();
            pokeSil.setImage(a.getRevealed());
            gssButt.setVisible(false);
            nxtButt.setVisible(true);
        }
        if(guesses == 3){
            youLost();
        }
    }

    @FXML
    void next(ActionEvent event) throws IOException {
        if (scoreTracker == 35)
        {
            youWon();
        }
       gssBox.clear();
       shuffleList.remove(a);
       playGame();
       nxtButt.setVisible(false);
       gssButt.setVisible(true);
       hintLbl.setVisible(false);
       if(!gssBox.isVisible())
       {
        setMultipleChoice();
       }
    }

    static int getScore()
        {
            return scoreTracker;
        }

    @FXML
    void updateGuessCount()
    {
        gssCountLbl.setText("Strikes: " + guesses);
    }

    @FXML 
    void updateScore()
    {
        scoreTracker++;
        scoreLbl.setText(scoreTracker + "/35");
    }

    @FXML
    void hintPlease(ActionEvent event) throws IOException{
        hintLbl.setVisible(true);
        hintLbl.setText(a.getHint());
    }

    @FXML
    void youLost() throws IOException{
        Stage stage;
        stage = (Stage) gssButt.getScene().getWindow();
        stage.close();
        FXMLLoader floot = new FXMLLoader(getClass().getResource("youLost.fxml"));
        Scene scene = new Scene(floot.load());
        stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void youWon() throws IOException
    {
        Stage stage;
        stage = (Stage) gssButt.getScene().getWindow();
        stage.close();
        FXMLLoader floot = new FXMLLoader(getClass().getResource("youWon.fxml"));
        Scene scene = new Scene(floot.load());
        stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void selectIt(ActionEvent event) {
        gssA.setVisible(true);
        gssB.setVisible(true);
        gssC.setVisible(true);
        gssD.setVisible(true);
        gssBox.setVisible(false);
        setMultipleChoice();
    }

    void setMultipleChoice()
    {
        ArrayList<String> answers = new ArrayList<>();
        answers.add(corrName);
        names.remove(corrName);
        for(int i = 0; i < 3; i++)
        {
        int e = random(names);
            answers.add(names.get(e));
            names.remove(names.get(e));
        }        
        reloadNames();
        Collections.shuffle(answers);
        gssA.setText(answers.get(0));
        gssB.setText(answers.get(1));
        gssC.setText(answers.get(2));
        gssD.setText(answers.get(3));
    }

    void reloadNames()
    {
        for(Pokemon p : init)
        {
            names.add(p.getName());
        }
    }

    @FXML
    void typeIt(ActionEvent event) {
        gssBox.setVisible(true);
        gssA.setVisible(false);
        gssB.setVisible(false);
        gssC.setVisible(false);
        gssD.setVisible(false);
    }

}
